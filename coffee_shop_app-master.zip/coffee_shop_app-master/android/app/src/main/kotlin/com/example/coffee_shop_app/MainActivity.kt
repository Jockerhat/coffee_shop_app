package com.rado.coffee_shop_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
